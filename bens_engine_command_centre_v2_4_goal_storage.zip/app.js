// V2.4 uses inline JavaScript in index.html
