# V2.4 Goal Storage

Each dropdown goal saves separately and combined totals are calculated.
